import Arr from "assets/img/arr-left.svg"
import Menu from "assets/img/menu-right.svg"
import { useNavigate } from "react-router-dom"

export const Header = ({ title, hasBack, hasMenu }: { title?: string, hasBack?: boolean, hasMenu?: boolean }) => {
  const nav = useNavigate()

  return <div className="common-menu">
    <div className="icon" onClick={() => nav(-1)} >
      {hasBack && <img src={Arr} alt="arr-left" />}
    </div>
    <p className="menu-title">
      {title}
    </p>
    <div className="icon">
      {hasMenu && <img src={Menu} />}
    </div>
  </div>
}

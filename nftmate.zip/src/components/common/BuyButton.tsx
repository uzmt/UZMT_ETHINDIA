import { Link } from "react-router-dom"


export const BuyButton = ({ to }: { to: string }) => {

  return <Link to={to}>
    <div className="buy-button">
      <p className="left-buy-text">
        Buy Rent ticket
      </p>
      <div className="right-buy-text eth">
        <p className="price-text big">0.321</p>
        <p className="price-unit big">ETH</p>
      </div>
    </div>

  </Link>


}

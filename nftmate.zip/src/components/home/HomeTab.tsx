import Bell from "../../assets/img/bell.svg"
import Logo from "../../assets/img/logo-w.svg"

export const HomeTab = () => {

  return <div className="home-tab-container">
    <img src={Logo} alt="logo" />
    <div className="select-circle">
      <div className="active circle">
        <p>
          For you
        </p>
      </div>
      <div className="circle">
        <p>
          Top 20 Ticket
        </p>
      </div>
    </div>
    <div className="bell-container">
      <img src={Bell} alt="bell" />
    </div>
  </div>
}

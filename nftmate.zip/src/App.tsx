import Routers from "./routes"

const App = () => {

  return (
    <div className="App">
      <Routers />
    </div>
  )
}

export default App

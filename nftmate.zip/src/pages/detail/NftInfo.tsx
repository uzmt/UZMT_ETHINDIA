import User from "assets/img/user.svg"
import { Header } from "components/common/Header"
import { BuyButton } from "components/common/BuyButton"

export const NftInfo = () => {

  return <div className="main">
    <Header title={"Ticket Detail"} hasBack hasMenu />
    <div className="content no-bottom">
      <div className="img-container detail">
        <div className="img-detail">
          <div className="img-top-info">
            <p className="title">
              Darkness
            </p>

            <div className="author-container">
              <div className="mr24">
                <p className="author dot-icon">
                  Yu-Gi-Yn
                </p>
              </div>
              <p className="date date-icon">2022. 11. 31 ~ 2022. 12. 05</p>
            </div>
          </div>

          <div className="card-info">
            <div className="profile-container mr23">
              <div className="user-profile">
                <img src={User} alt="user-icon" />
              </div>

              <div className="user-detail">
                <p className="name">Salvador Dali</p>
                <p className="cnt">23,201 Rent Tickets</p>
              </div>
            </div>
          </div>

          <div className="dim"></div>
        </div>
      </div>

      <BuyButton to="/purchase" />
    </div>
  </div>
}

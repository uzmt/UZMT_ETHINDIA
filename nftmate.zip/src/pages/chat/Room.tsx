
export const Room = () => {

  return <div className="room">

  </div>
}

import { BottomTab } from "components/common/BottomTab"

export const Profile = () => {

  return <div>
    Profile

    <BottomTab theme={"light"} />
  </div>

}

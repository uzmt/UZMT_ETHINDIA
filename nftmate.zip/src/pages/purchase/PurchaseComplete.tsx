import Main from "assets/img/main-img.png"
import Qr from "assets/img/qr.svg"
import Copy from "assets/img/copy.svg"
import Logo from "assets/img/logo-w.svg"
import { Header } from "components/common/Header"
import { useState } from "react"
import { Link } from "react-router-dom"

export const PurchaseComplete = () => {

  const [showQr, setShowQr] = useState(false)

  return <div className="main">
    <Header title={"Purchase Complete"} />
    <div className="content no-bottom">
      <div className="complete-img">
        <img src={Main} alt="main" />
        <div className={`qr-img ${showQr ? "active" : 0}`}>
          <img src={Qr} alt="" />
          <div className="d-flex colum y-center">
            <div className="mb8">
              <img src={Logo} alt="" />
            </div>
            <p>
              Scan the QR Code
            </p>
          </div>
        </div>
      </div>


      <div className="img-detail">
        {showQr ? <div className="top-desc"><div className="copy-container">
          <p>
            Tokenkd31021mdoq301...mdoq301eQ5D
          </p>
          <img src={Copy} alt="" />
        </div> </div> : <div className="top-desc">
          <p className="title">
            Darkness
          </p>

          <div className="author-container">
            <div className="mr24">
              <p className="author dot-icon">
                Yu-Gi-Yn
              </p>
            </div>
            <p className="date date-icon">2022. 11. 31 ~ 2022. 12. 05</p>
          </div>
        </div>}


        <div className={`button-button ${showQr ? "x-center" : ""}`}>
          {showQr ?
            <div className="button-type1 middle width112" onClick={() => setShowQr(!showQr)}>
              <p>
                Confirm
              </p>
            </div>
            :
            <>
              <div className="price-info eth">
                <p className="price-text mr4">0.321</p>
                <p className="price-unit opacity5">ETH</p>
              </div>
              <div className="d-flex x-center y-center">
                <div className="button-type1 middle mr12" onClick={() => setShowQr(!showQr)}>
                  <p>
                    QR Code
                  </p>
                </div>
                <div className="button-type2 middle flex1 mr8">
                  <p>
                    Share
                  </p>
                </div>
              </div>
            </>

          }

        </div>

      </div>



      <div className="bottom-button">
        <div className="button-type2 flex1 mr8">
          <p>
            Ticket list
          </p>
        </div>

        <div className="button-type1 flex2">
          <Link to="/home">
            <p>
              Cofirm
            </p>
          </Link>

        </div>

      </div>
    </div>
  </div>
}
